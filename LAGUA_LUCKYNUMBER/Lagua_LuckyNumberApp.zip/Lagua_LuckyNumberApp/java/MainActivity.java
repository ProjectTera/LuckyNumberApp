package com.example.luckynumbergenerator;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    public Button btnClaim;
    public EditText edtName;

    private String name;

    /*
     * TODO
     *  - Background
     *  - Fix layout
     * */

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edtName = findViewById(R.id.edtName);

        btnClaim = findViewById(R.id.btnClaim);
        btnClaim.setOnClickListener(view -> {

            name = edtName.getText().toString();

            if (hasName(name))
                shareData(name);
            else
            {
                Toast toast = Toast.makeText(this, "Please put a name", Toast.LENGTH_SHORT);
                toast.show();
            }

        });
    }

    public void shareData(String text) {
        Intent i = new Intent(getApplicationContext(), LuckyNumberActivity.class);
        i.putExtra("name", text);
        startActivity(i);
    }

    public boolean hasName(String inputName) {
        return !(inputName.isEmpty() && inputName.isBlank());
    }
}