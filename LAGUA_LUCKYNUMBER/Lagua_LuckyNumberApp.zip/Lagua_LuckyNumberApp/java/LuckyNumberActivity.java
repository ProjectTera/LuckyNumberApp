package com.example.luckynumbergenerator;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class LuckyNumberActivity extends AppCompatActivity {

    final int min = 0;
    final int max = 100;
    private int luckyNumber;
    private String url = "";

    public Button btnWeb;
    public Button btnBack;
    public TextView tvLuckyNumber;

    /*
    * TODO
    *  - Background
    *  - Fix layout
    * */

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lucky_number);

        Intent i = getIntent();
        String message = "Nice " + i.getStringExtra("name");

        btnBack = findViewById(R.id.btnBack);
        btnWeb = findViewById(R.id.btnWeb);
        tvLuckyNumber = findViewById(R.id.tvLuckyNumber);

        luckyNumber = generateLuckyNumber();
        url = luckyNumber == 69 ? "https://www.youtube.com/watch?v=dQw4w9WgXcQ" : "https://youtu.be/jNQXAC9IVRw?si=LU0CGMCVZ4OprC4s";

        tvLuckyNumber.setText(String.valueOf(luckyNumber));

        btnBack.setOnClickListener(view -> {
            returnMain();
        });

        btnWeb.setText(message);
        btnWeb.setOnClickListener(view -> {
            openUrl(url);
        });

    }

    public int generateLuckyNumber() {
        return min + (int)(Math.random() * ((max - min) + 1));
    }

    public void openUrl(String weblink) {
        Uri webpage = Uri.parse(weblink);
        Intent i = new Intent(Intent.ACTION_VIEW, webpage);
        startActivity(i);
    }

    public void returnMain() {
        Intent i = new Intent(this, MainActivity.class);
        startActivity(i);
    }
}