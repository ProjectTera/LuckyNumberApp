package com.example.intent_activity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import java.util.Random;

public class SecondPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second_page);

        Random myRandom = new Random();
        int randNum = myRandom.nextInt(100);

        TextView txtNum = findViewById(R.id.txtNum);
        Button btnName = findViewById(R.id.btnName);
        Button btnBack = findViewById(R.id.btnBack);

        Intent i = getIntent();
        String name = i.getStringExtra("name");

        btnName.setText("Nice " + name);
        txtNum.setText(randNum + "");

        btnName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openURL();
            }
        });

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(i);
            }
        });

    }

    public void openURL(){
        Uri webpage = Uri.parse("https://www.youtube.com/watch?v=jNQXAC9IVRw&pp=ygUJbWUgYXQgem9v");
        Intent i = new Intent(Intent.ACTION_VIEW, webpage); //open def browser of the phone and opens webpage
        startActivity(i);
    }
}