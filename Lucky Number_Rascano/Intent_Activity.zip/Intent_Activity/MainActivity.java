package com.example.intent_activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnGenerate = findViewById(R.id.btnGenerate);
        EditText edtxtName = findViewById(R.id.edtxtName);

        btnGenerate.setOnClickListener(new View.OnClickListener() {
               @Override
               public void onClick(View view) {
                   shareName(edtxtName.getText().toString());
               }
           });
    }

    public void shareName(String name){
        Intent i = new Intent(getApplicationContext(), SecondPage.class);
        i.putExtra("name", name); //key val pair
        startActivity(i);
    }
}