package com.example.randomizer;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Random;

public class Lucky extends AppCompatActivity {
    Random num =new Random();
    int nums = num.nextInt(10)+1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lucky);
        EdgeToEdge.enable(this);

        Button btnnice = findViewById(R.id.btnnice);
        TextView textView3 = findViewById(R.id.textView3);
        Intent i = getIntent();

        String data = i.getStringExtra("name");
        btnnice.setText("Nice one! "+ data+"!!!");
        textView3.setText(" " + nums);

        btnnice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openURL();
            }
        });
        Button btnback = findViewById(R.id.btnback);
        btnback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                goback();
            }
        });
    }

    // --Implicit = communication of app to external apps
    public void openURL(){
        Uri webpage = Uri.parse("https://www.youtube.com/watch?v=jNQXAC9IVRw");
        Intent i = new Intent(Intent.ACTION_VIEW,webpage);
        startActivity(i);
    }
    public void goback(){
        Intent i = new Intent(this, MainActivity.class);
        startActivity(i);
    }
}