package com.example.activity2_randomize;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnGenerate= findViewById(R.id.btnGenerate);
        EditText txtName = findViewById(R.id.txtName);
        btnGenerate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                nextpage(txtName.getText().toString());
            }
        });
    }

    public void nextpage(String dataname){
        Intent o = new Intent(getApplicationContext(), MainActivity2.class);
        o.putExtra("name", dataname);
        startActivity(o);
    }
}

