package com.example.activity2_randomize;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Random;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        TextView randomizedNum = findViewById(R.id.randomizedNum);
        Button btnLink = findViewById(R.id.btnLink);
        Button btnBack = findViewById(R.id.btnBack);
        Intent o =  getIntent();

        String data = o.getStringExtra("name");
        btnLink.setText("Nice, " + data + "!!!");

        Random randomnumber = new Random();
        int rnum = randomnumber.nextInt(100);
        randomizedNum.setText(String.valueOf(rnum));

        btnLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openurl();
            }
        });

        btnBack.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Intent back = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(back);
            }

        });
    }

    public void openurl(){
        Uri webpage = Uri.parse("https://www.youtube.com/watch?v=jNQXAC9IVRw");

        Intent i = new Intent(Intent.ACTION_VIEW, webpage);
        startActivity(i);
    }

}