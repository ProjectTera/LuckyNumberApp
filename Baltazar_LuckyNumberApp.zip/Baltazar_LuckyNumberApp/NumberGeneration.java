    package com.example.activity2;

    import android.content.Intent;
    import android.net.Uri;
    import android.os.Bundle;
    import android.view.View;
    import android.widget.Button;
    import android.widget.TextView;

    import androidx.activity.EdgeToEdge;
    import androidx.appcompat.app.AppCompatActivity;
    import androidx.core.graphics.Insets;
    import androidx.core.view.ViewCompat;
    import androidx.core.view.WindowInsetsCompat;

    import java.text.BreakIterator;
    import java.util.Random;

    public class NumberGeneration extends AppCompatActivity {

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_number_generation);

            Button btn_zoo = findViewById(R.id.btn_zoo);
            Button btn_zoo2 = findViewById(R.id.btn_zoo2);

            btn_zoo.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    openUrl();
                }
            });
            btn_zoo2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    FirstScreen();
                }
            });
        }

        protected void onStart() {
            super.onStart();
            TextView textView = findViewById(R.id.textView);
            Random random = new Random();
            int randomNumber = random.nextInt(100) + 1;
            textView.setText(String.valueOf(randomNumber));

            Intent i = getIntent();
            String data = i.getStringExtra("name");
            Button btn_zoo = findViewById(R.id.btn_zoo);
            btn_zoo.setText("Nice One, " + data + "!");
        }

        public void openUrl() {
            Uri webpage = Uri.parse("https://www.youtube.com/watch?v=jNQXAC9IVRw");
            Intent i = new Intent(Intent.ACTION_VIEW, webpage);
            startActivity(i);
        }

        public void FirstScreen() {
            Intent i = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(i);
        }
    }
